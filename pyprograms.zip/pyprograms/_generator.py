def fun(a,b):
    yield a+b
    yield a*b
out=fun(2,3)
#print(list(out))#[5,6]
for i in out:#output 5 6 in two lines
    print(i)