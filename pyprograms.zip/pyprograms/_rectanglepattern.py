row = int(input("Enter number of rows: "))
col = int(input("Enter number of columns: "))

#print("Rectangular pattern is: ")
for i in range(1,row+1):
    for j in range(1,col+1):
        print("+", end=" ")
    print()