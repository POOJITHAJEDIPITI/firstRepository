def filter(string):
    out=''
    vowels='aeiouAEIOU'
    for k in string:
        if k in vowels:
            out+=k
    return out
def extract(st):
    res=''
    for j in 'aeiouAEIOU':
        if j not in st:
            res+=j
    return res
print(extract(filter('hello')))
        