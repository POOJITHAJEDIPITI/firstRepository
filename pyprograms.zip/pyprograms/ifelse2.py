a=eval(input('enter a character'))
if 0<=a and 9>=a:
    print('digit')
else:
    print('not digit')