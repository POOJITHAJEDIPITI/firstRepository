str=input('entera a string')
out={}
i=0
while i<len(str):
    if str[i] not in out:
        out[str[i]]=1
    i+=1
else:
    out[str[i]]+=1
print(out)
