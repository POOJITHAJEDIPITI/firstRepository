class a:
    __a=10
    b=20
    def __init__(self,c):
        self.c=c
    def display(self):
        print(self.c)
    @classmethod
    def display1(cls):
        return cls.__a
obj=a(3)
print(obj.display1())
print(obj.b)
print(obj.__a)
    