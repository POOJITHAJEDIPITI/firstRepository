import re
out=re.findall('\+91\-[6-9][0-9]{9}','dfggh+91-asf6237657657hn9')
print(out)