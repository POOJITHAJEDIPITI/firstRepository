class parent:
    a=10
    b=20
    def __init__(self,c,d):
       self.c=c
       self.d=d
class child(parent):
    pass
obj=child(30,40)

print(obj.a)
print(obj.b)
print(obj.c)
print(obj.d)