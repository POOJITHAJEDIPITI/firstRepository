def fun():
    out=[ i**2 for i in range(5,16)]
    return out
print(fun())