str=input('enter a string')
out=[]
i=0
start=0
while i<len(str):
    if str[i]==' ':
        #if start<i:
          out+=[str[start:i]]
          start=i+1
    i+=1
if start<len(str):
    out+=[str[start:]]
print(out)
