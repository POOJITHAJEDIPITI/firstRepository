def fun(str1,str2):
    out=0
    if len(str1)==len(str2):
            for i in range(len(str1)):
                if str1[i]!=str2[i]:
                    out+=1
            print(out)
    else:
        print('length of two strings are not equal')
fun('abcde','abcde')
fun('strong','strung')
fun('pil','lip')
fun('ab','abc')

