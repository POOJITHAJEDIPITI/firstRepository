import random
number=random.randint(1,50)
while True:
    a=int(input('enter a num'))
    if a==number:
        print('congrats')
        break
    elif a>number:
        print('enter lesser num')
    else:
        print('enter greater num')