class grandparent:
    a=1
    def __init__(self,x):
       self.x=x
    def display(self,p):
        self.p=p
        print(self.p)
class parent(grandparent):
    b=2
    def __init__(self,x,y):
        super().__init__(x)
        self.y=y
    def display(self,p,q):
        super().display(p)
        self.q=q
        print(self.q)
class child(parent):
    c=3
    def __init__(self,x,y,z):
        super().__init__(x,y)
        self.z=z
    def display(self,p,q,r):
        super().display(p,q)
        self.r=r
        return self.r
obj=child(10,20,30)
print(obj.a)
print(obj.b)
print(obj.c)
print(obj.x)
print(obj.y)
print(obj.z)
print(obj.display(100,200,300))