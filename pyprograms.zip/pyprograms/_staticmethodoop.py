class mtca:
    college='mti'
    principal='Mr.prabhakar'
    location='palamaner'
    def __init__(self,sname,mobile,email):
        self.name=sname
        self.mnum=mobile
        self.mail=email
    def mob_update(self,new):
        self.mnum=new
        print('mobile number updated')
    @staticmethod
    def add(a,b):
        return a+b
obj=mtca('vikitha',9876,'mail')
print(obj.name)
print(obj.add(2,3))