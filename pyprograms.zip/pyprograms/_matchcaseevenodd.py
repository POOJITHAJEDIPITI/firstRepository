a=int(input('enter a number'))
#if is is even square else cube

match a%2:
   case 0:
          print(a*a)
   case _:
          print(a**3)
   

    