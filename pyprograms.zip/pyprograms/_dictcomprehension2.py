def fun():
    a='xyz'
    b=[1,2,3]
    #out={a[i]:b[i] for i in range(len(a))}
    out={i:j for i,j in zip(a,b)}
    return out
print(fun())