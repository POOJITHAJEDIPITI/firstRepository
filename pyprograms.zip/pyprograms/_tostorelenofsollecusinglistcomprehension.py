def fun():
    a=[[1,2,3],'abcd',(1,2),{1,2,3}]
    out=[ len(i) for i in a]
    return out
print(fun())