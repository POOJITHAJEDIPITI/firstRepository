a=input('enter a string')
out=''
dup=''
for i in a:
    if i not in out:
        out+=i
    else:
        dup+=i
print(dup)