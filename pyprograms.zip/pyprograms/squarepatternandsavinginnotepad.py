row=int(input('enter rows'))
out=''
for i in range(row):
    for j in range(row):
        if i==j or i==row-j-1:
            out+=' '
        else:
            out+='+'
    out+='\n'
name=input('enter file name')
file=open(f'{name}.txt','w')
file.write(out)
file.close()