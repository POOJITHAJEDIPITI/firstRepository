a=input('enter a string')
b=' '
index=0
while index<len(a):
    if 'a'<=a[index]<='z':
        b+=chr(ord(a[index])-32)
    else:
        b+=a[index]
    index+=1
print(b)