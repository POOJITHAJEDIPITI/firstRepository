a=input('enter a string')
n=-len(a)
count=0
while n<0:
    if a[n] in 'aeiouAEIOU':
        count+=1
    n+=1
print(count)
 