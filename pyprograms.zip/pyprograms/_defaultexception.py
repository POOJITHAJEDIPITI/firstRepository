a=10
try:
    while True:
        continue
except:
    print('handled')