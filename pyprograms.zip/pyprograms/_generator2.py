def fun(num):
    a=1
    for i in range(1,num+1):
        yield a
        a*=2#output 1,2,4,8,16,32,64,128....
out=fun(10)
print(list(out))