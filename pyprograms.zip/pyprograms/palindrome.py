num=int(input('enter a number'))
temp=str(num)
out=''
for k in temp:
     out+=k
if int(out)==num:
     print('palindrome')
else:
     print('not palindrome')