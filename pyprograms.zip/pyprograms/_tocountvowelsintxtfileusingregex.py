import re
file=open(r"C:\Users\administrator.MCA\Desktop\newfile.txt",'r')
data=file.read()
out=re.findall('[aeiouAEIOU]',data)
print(len(out))