b=''
for k in 'user@123#admin':
    if not '0'<=k<='9':
        b+=k
print(b)
     
    