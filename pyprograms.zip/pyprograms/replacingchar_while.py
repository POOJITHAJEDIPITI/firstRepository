str = input('enter a string')
index = 0
str1 = ""
while index < len(str):
    if str[index] == "v":
        str1 += "vv"
    else:
        str1 += str[index]
    index += 1
print(str1)
