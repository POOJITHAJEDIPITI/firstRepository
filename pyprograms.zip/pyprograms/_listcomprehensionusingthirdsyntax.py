def fun():
    out=[ i*i if i%2==0 else i**3 for i in range(1,21)]
    return out
print(fun())