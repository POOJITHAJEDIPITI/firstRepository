a=input('enter a string')
out=[]
i=0
while i<len(a):
    if a[i] in 'aeiouAEIOU':
       out=out+[i]
    i+=1
print(out)
