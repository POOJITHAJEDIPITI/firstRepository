x=eval(input('enter a value:'))
if type(x) in [bool,complex,int,float]:
    print(x**2)
else:
    print((3*len(x)+1))
