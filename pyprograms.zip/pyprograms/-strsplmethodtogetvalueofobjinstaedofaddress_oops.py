class demo:
    def __init__(self,a):
        self.a=a
    def __repr__(self):
        return str(self.a)
obj=demo(4)
print(obj)