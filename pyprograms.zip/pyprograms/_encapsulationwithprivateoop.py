class A:
    __a=10
    b=20
    def __init__(self,c):
        self.c=c
    def display(self):
        print(self.c)
    @classmethod
    def display1(cls):
        return cls.__a
obj=A(3)
print(obj.display1())
print(obj.b)
#print(obj.__a)
print(obj._A__a)
    