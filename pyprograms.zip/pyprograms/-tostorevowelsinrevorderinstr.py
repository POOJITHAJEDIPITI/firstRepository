def fun(str):
    vowels=''
    for k in str:
        if k in 'aeiouAEIOU':
            vowels+=k
    res=''
    temp=-1
    for k in str:
        if k in 'aeiouAEIOU':
           res+=vowels[temp]
           temp+=-1#to remove last char from vowels
        else:
            res+=k
    print(res)
fun('hello')