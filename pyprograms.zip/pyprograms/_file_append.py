file=open('sample.txt1','a')
data='happy republic day1 '
file.write(data)
file.close()#write-overrides, append-add new data to existing data