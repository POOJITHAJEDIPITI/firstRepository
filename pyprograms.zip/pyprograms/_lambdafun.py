print((lambda a,b:a+b)(1,2))
print((lambda num:num%2==0)(2))
print((lambda num:num%7==0)(48))
print((lambda str:'a' in str)('vikitha'))