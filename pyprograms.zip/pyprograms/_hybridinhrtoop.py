class a:
    a=10
class b(a):
    b=20
class c(a):
    c=30
class d(c,b):
    d=40
obj1=d()
print(obj1.a)
print(obj1.b)
print(obj1.c)
print(obj1.d)
