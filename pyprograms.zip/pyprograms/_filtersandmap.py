def fun(num):
   
        return num**3
def even(num):
        if num%2==0:
                return num
    
a=[1,2,4,5,7,8]
print(list(map(fun,filter(even,a))))
