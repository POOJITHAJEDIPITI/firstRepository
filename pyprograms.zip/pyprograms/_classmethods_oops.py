class mtca:
    college='mti'
    principal='Mr.prabhakar'
    location='palamaner'
    def __init__(self,sname,mobile,email):
        self.name=sname
        self.mnum=mobile
        self.mail=email
    def mob_update(self,new):
        self.mnum=new
        print('mobile number updated')
    @classmethod#used to pass the address of class eventhough we call function using obj
    def changeprincipal(cls,new):
        cls.principal=new
vikitha=mtca('vikitha',9876543,'vikitha@gmail.com')
vikitha.changeprincipal('viki')
print(mtca.principal)
print(vikitha.principal)