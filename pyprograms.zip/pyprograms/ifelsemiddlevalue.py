a=eval(input('enter a collection'))
if len(a)%2!=0:
   print(a[len(a)//2])
else:
   print(a[0: :len(a)-1])
    