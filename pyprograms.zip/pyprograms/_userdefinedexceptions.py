class VikiError(Exception):#exception is predefined class we are derriving one new class
   pass
class MobNumError(Exception):
     pass
try:
   name=input('enter name  ')
   if len(name)<4:
     raise VikiError('name should be morethan 4 char')
   else:
       print('hi',name)

   num=int(input('enter mobile number'))
   if len(str(num))!=10:
     raise MobNumError(f'mobile number should be 10 digits but {len(str(num))} were given')
   else:
     print('your mobile number is',num)
except (VikiError,MobNumError) as e:
    print(e)
