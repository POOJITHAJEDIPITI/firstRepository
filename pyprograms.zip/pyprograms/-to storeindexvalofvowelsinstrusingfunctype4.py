def index(str):
    out=[]
    for k in range(len(str)):
        if str[k] in 'aeiouAEIOU':
            out+=[k]
    return out
print(index('vikitha'))
print(index('aeiou'))
print(index('viki'))