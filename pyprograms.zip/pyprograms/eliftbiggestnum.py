a=int(input('enter a value:'))
b=int(input('enter a value:'))
c=int(input('enter a value:'))
if a==b==c:
    print('three are equal')
elif a==b:
    print('a and b are equal')
elif b==c:
    print('b and c are equal')
elif a>b and a>c:
      print('a is big')
elif a<b and a>c:
    print('B is big')
else:
    print('C is big')
      
