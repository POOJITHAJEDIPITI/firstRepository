a,b=0,1
n=int(input('enter range'))
print(a,end=' ')
for i in range(n):
    print(b,end=' ')
    a,b=b,a+b

