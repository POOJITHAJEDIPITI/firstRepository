class parent:
    a=10
    def __init__(self,b):
        self.b=b
    def display(self,x):
       self.x=x
       print(self.x)
class child(parent):
    a=20
    def __init__(self,b,e):
        super().__init__(b)
        self.e=e
    
    def display(self,x,y):
       parent.display(self,x)
        #super().display(x)
       self.y=y
       return self.y
obj=child(50,60)
print(obj.b)
print(obj.e)
print(obj.display(10,20))