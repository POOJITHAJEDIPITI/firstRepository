a=input('enter a character:')
if '0'<=a and '9'>=a:
          print('digit')
elif 'A'<=a and 'Z'>=a:
    print('uppercase')
elif 'a'<=a and 'z'>=a:
    print('lowercase')
else:
    print('special character')
