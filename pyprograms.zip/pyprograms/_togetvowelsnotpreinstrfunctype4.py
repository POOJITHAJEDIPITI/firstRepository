def vowel(str):
    out=''
    b='aeiouAEIOU'
    for k in b:
        if k not in str :
            out+=k
    return out
print(vowel('viki'))
    