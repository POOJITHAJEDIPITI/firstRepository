num=int(input('enter a number:'))
count=0
i=1
while num>=i:
    if num%i==0:
        count+=1
    i+=1
if count==2:
    print('prime num')
else:
    print('not prime')
