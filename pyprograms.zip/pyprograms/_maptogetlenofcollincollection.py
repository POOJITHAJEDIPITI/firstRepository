def fun(num):
    if type(num) in [list,str,tuple,set,dict]:
        return len(num)
    else:
        return num
a=[1,2,[4,5,6],'xyz',(4,1,2,3)]#output:[1,2,3,3,4]
print(list(map(fun,a)))