from functools import reduce
a=['hi','my','name','is','viki']
print(reduce(lambda x,y:x+' '+y,a))