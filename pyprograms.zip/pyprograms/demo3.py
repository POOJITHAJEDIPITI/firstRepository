class kart:
    quantity={'tv':10,'mobile':20,'laptop':5}
    price={'tv':10000,'mobile':5000,'laptop':20000}
    
    def __init__(self,name,mob,loc):
        self.name=name
        self.mob=mob
        self.loc=loc
        self.productqty=0
        self.totalprice=0

    @classmethod
    def __modify_class(cls,product,qty):
        cls.quantity[product]-=qty
    
    @classmethod
    def available_product(cls):
        print(cls.quantity)

    def getbill(self):
        custid=self.name[0:4]+str(self.mob)[-4:]
        data=f'''
        custid: {custid}
        name  : {self.name}
        mobile: {self.mob}
        location:{self.loc}
        total quantity booked: {self.productqty}
        total price          :{self.totalprice}
        Thankyou for visiting my kart!!!

            def availableproduct(self):
        print(self.quantity)
    def booking(self):
        print(''' select from the following
              1.tv
              2.mobile
              3.laptop''')
        res=int(input('enter any num'))
        out=int(input('enter quantity'))
        res1=input('do you want to book')
        if res1=='y':
            if res=='1':

            self.productqty+=out
            self.totalprice=out*
            print(f'you booked {self.productqty} and the price is ')
            print('do you want to shop more: ')
            res2=('press y or press any key to exit')

obj=kart('viki',999999,'ctr')
print(obj.availableproduct())
print(obj.booking())