import re
file=open(r"C:\Users\administrator.MCA\Desktop\newfile.txt",'r')
data=file.read()
out=re.sub(' ','*',data)
#print(out)
file=open(r"C:\Users\administrator.MCA\Desktop\newfile.txt",'w')
#file.seek(0)
file.write(out)
file.close()