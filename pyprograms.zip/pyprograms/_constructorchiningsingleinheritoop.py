class parent:
    a=10
    b=20
    def __init__(self,c,d):
       self.c=c
       self.d=d
class child(parent):
    a=20
    def __init__(self,c,d,e,f):
        super().__init__(c,d)
        self.e=e
        self.f=f
obj=child(30,40,50,60)
print(vars(obj))
print(obj.a)
print(obj.b)
print(obj.c)
print(obj.d)
print(obj.e)
print(obj.f)