def fun(a,*b,**kwargs):
    print(a,list(b),kwargs)
fun(1,2,3,c=20,d=1,e=4)
    