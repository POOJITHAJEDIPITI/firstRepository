from abc import ABC,abstractmethod
class modelcar(ABC):
     @abstractmethod
     def brake():
        pass
     @abstractmethod
     def speedup():
         pass
     @abstractmethod
     def speeddown():
         pass
class nexon(modelcar):
    def __init__(self,speed=0,stop=True):
        self.speed=speed
        self.stop=stop
    def speedup(self):
         self.speed+=10
         self.stop=False
         return f'accelerated by 5km/hr and current speed is {self.speed} km/hr'
    def speeddown(self):
        if not self.stop:
          self.speed-=5
          if self.speed==0:
            self.stop=True
        return f'deaccelerated by 5km/hr and current speed is {self.speed} km/hr'
               
    def brake(self):
        self.speed=0
        self.stop=True
        print(self.stop)
        return f'stopped and current speed is {self.speed} km/hr'
class indica(modelcar):
    def __init__(self,speed=0,stop=True):
        self.speed=speed
        self.stop=stop
    def speedup(self):
         self.speed+=10
         self.stop=False
         return f'accelerated by 2km/hr and current speed is {self.speed} km/hr'
    def speeddown(self):
        if not self.stop:
          self.speed-=5
          if self.speed==0:
            self.stop=True
        return f'deaccelerated by 2km/hr and current speed is {self.speed} km/hr'
               
    def brake(self):
        self.speed=0
        self.stop=True
        print(self.stop)
        return f'stopped and current speed is {self.speed} km/hr'
nexon1=nexon()
print(nexon1.speedup())
print(nexon1.speeddown())
indica1=indica()
print(indica1.speedup())
print(indica1.speeddown())

    
    
     
    



