a=[2,8,6,4,3,23,2,1,8,9]
out=list(map(lambda num:num*num,a))
print(out)