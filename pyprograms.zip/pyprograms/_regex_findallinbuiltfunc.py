import re
out=re.findall('[0-9]','abcdef12gh45')
print(out)