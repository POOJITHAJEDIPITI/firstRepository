class polymrphsm:
    @staticmethod
    def add(a,b):
       return a+b
    @staticmethod
    def add(a,b,c):
      return a+b+c
obj=polymrphsm()
print(obj.add(1,2,3))
#print(add(1,2))error 1 arg missing bcoz method overriding,we cannot give multiple forms for a function bcoz in python we dont have method overloading