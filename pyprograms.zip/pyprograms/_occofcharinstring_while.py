str=input('enter a string:')#occurence of character in string using while
ch=eval(input('enter a character'))
count=0
n=0
while n<len(str):
    if str[n]==ch:
        count+=1
    n+=1
print(count)
