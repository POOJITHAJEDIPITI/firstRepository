a=eval(input('enter a character'))
if 65<=ord(a) and 97>=ord(a):
    print('uppercase')
else:
    print('lowercase')