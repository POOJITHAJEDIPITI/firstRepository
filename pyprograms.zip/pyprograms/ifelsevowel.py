vowel=eval(input('enter alphabet'))
if vowel in 'aeiou':
    print('vowel')
else:
    print('consonant')