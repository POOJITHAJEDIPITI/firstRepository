a=input('enter a string')
b=' '
index=0
temp=True
while index<len(a):
    if a[index]==' ':
      temp=True
    elif temp and'a'<=a[index]<='z':
            b+=chr(ord(a[index])-32)
            temp=False
    else:
        b+=a[index]
        temp=False
    index+=1
print(b)