str=input('enter a string')
out={}
for char in str:
    if char not in out:
        out[char]=1
    else:
        out[char]+=1
print(out)