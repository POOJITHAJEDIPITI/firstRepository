def add(num):
    temp=str(num)
    if len(temp)==6:
       sum=0
       for k in temp:
          if int(k)%2==0:
            sum+=int(k)
       return sum
   # else:
      # print('enter morethan 6 digit number')
y=add(123456)
print(y)
#x=add(24681)
#print(x)
print(add(222222))
print(add(123))