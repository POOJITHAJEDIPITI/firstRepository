import time

def duration(func):
    def inner():
        start=time.time()
        func()
        end=time.time()
        print(f'the total time taken to answer the question is {end-start} sec')
    return inner
@duration
def question1():
    print('who is the principal')
    response=input('enter')

@duration
def question2():
    print('who is PM')
    response=input('enter')
@duration
def question3():
    print('who is the CM')
    response=input('enter')
question1()
question2()
question3()
