row=int(input('enter rows'))
for i in range(row):
    for j in range(row):
        if ior j==i+1:
            print(' ',end=" ")
        else:
            print('+',end=" ")
    print()