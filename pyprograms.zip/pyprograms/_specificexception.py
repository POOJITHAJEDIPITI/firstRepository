a=10
try:
    a/0
except ZeroDivisionError:
   print('handled')