def count():
    a=int(input('enter a num'))
    print(len(str(a)))
count()