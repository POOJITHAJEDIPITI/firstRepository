def fun(str):
    lower=''
    upper=''
    temp=''
    for i in str:
        if 'a'<=i<='z':
            lower+=i
        elif 'A'<=i<='Z':
            upper+=i
        else:
            temp+=i
    return lower+upper
print(fun('ViKiTha'))
