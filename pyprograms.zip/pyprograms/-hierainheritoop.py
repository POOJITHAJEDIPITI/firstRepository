class mti:
    chairman='Mr.Sunil'
    location='palamaner'
    collegename='mti'
    def __init__(self,name1):
        self.name1=name1
class mtca(mti):
    principal='Mr.prabhakar'
    strength=240
    staff=9
    
   
class mtiet(mti):
    principal='eeeee'
    strength=1000
    staff=40
    
obj1=mtca('vikitha')
obj2=mtiet('viki')
print(obj1.chairman)
print(obj2.chairman)
print(obj1.principal)
print(obj2.principal)


  