def sequence(num1,num2,num3):
    out=[]
    for k in range(num1,num2+1,num3):
        out+=[k]
        #num1+=num3
    print(out)
#sequence(1,10,1)