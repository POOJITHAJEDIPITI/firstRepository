from functools import reduce
a=[1,2,3,4,5]
print(reduce(lambda x,y:x+y,list(map(lambda x:x*x,a))))

