row=int(input('enter rows'))
for i in range(row):
    for j in range(row):
        if i==j or i==row-j-1:
            print(' ',end=" ")
        else:
            print('+',end=" ")
    print()