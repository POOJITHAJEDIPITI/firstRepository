a=[1,2,3,4,5]
res=[]
for k in a:
   fact=1
   for i in range(1,k+1):
       fact*=i
   res+=[fact]
print(res)