res=[]
for k in range(100,1001):
    b=k
    d=0
    while b>0:
        c=b%10
        d=(d*10)+c
        b=b//10
        if(d==k):
            res+=[k]
        
print(res)
