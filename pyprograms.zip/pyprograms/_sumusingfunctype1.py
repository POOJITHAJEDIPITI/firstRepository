def add():
    a=int(input('enter a value'))
    b=int(input('enter b value'))
    print(a+b)
add()