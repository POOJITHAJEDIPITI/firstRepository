def fact(num):
   a,b=0,1
   if num==1:
      yield 0
   else:
     for i in range(num):
       yield a
       a,b=b,a+b
out=fact(1)
print(list(out))
