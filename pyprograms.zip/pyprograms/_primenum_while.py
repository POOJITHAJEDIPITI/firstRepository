num=int(input('enter a number:'))
count=0
i=1
while num>0:
    if num%i==0:
        count+=1
    i+=1
if(count==2):
    print('prime num')
else:
    print('not primt')
