a=input('enter a string')
out=[]
for i in range(len(a)):
    if a[i] in 'aeiouAEIOU':
        out+=[i]
print(out)
