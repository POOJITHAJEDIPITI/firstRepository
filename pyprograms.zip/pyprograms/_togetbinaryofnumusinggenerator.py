def fun(num):
    out=0
    for i in range(num):
        out=num%2
        yield out
        num=num//2
        if num<1:
            break
res=fun(10)#to get binary[1,0,1,0]
print(list(res)[::-1])
        