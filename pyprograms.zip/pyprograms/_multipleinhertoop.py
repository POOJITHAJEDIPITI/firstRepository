class add:
    @staticmethod
    def add1(a,b):
        return a+b
    @staticmethod
    def add2(a,b,c):
        return a+b+c
class sub:
    @staticmethod
    def sub(a,b):
        return a-b
class mul:
    @staticmethod
    def mul(a,b):
        return a*b
class child(add,sub,mul):
    pass
obj=child()
print(obj.add1(1,2))
print(obj.add2(1,2,3))
print(obj.sub(3,2))
print(obj.mul(2,2))