def fun():
    a=[4,9,'abc',[1,2,3,4]]#output {0:4,1:9,2:'abc',3:[1,2,3,4]}
    #out={i:a[i] for i in range(len(a))}
    out={i:j for i,j in enumerate(a)}
    return out
print(fun())