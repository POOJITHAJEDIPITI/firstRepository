class circle:
    def __init__(self,r):
        self.r=r
    def area(self):
        return 3.14*self.r**2
    def circumference(self):
        return 2*3.14*self.r
    def diameter(self):
        return 2*self.r
obj=circle(3)
print(obj.area())
print(obj.circumference())
print(obj.diameter())