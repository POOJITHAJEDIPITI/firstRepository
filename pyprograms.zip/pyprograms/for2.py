a=input('enter')
out=''
for i in range(len(a)):
    #if i!=len(a)-1 and a[i] in a[i+1:]:
       if a[i] in a[i+1:]:
          if a[i] not in out:
            out+=a[i]
print(out)