def occurence(str,chr):
    count=0
   # n=0
    #while n<len(str):
        #if str[n]==chr:
          # count+=1
        #n+=1
    for k in str:
       if k==chr:
          count+=1
    print(count)
occurence('vikitha','i')
occurence('vikivikivv','v')
occurence('vikivikivv','k')