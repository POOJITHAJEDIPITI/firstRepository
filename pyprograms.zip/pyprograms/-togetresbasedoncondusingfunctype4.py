def demo(a):
    out=[]
    for k in range (len(a)):
        if k%2==0:
            if a[k]%2==0:
                out+=[(k**2)+(a[k]**2)]
            else:
                out+=[k+a[k]]
        else:
            if a[k]%2!=0:
                out+=[(k**2)+(a[k]**2)]
            else:
                out+=[k+a[k]]
    return out
print(demo([2,4,9,7,11,2,4,3,5,7,6]))
            
      
         
         
    