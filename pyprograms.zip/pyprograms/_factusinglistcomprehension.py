def fact(num):
    fact=1
    for i in range(1,num+1):
        fact*=i
    return fact
out=[fact(i) for i in range(1,11) if i%2==0]
print(out)