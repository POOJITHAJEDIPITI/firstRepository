sum=0
a=[1,'1',2,2.4,[4,5,6],9,16,'abcd']
#a=[1,2,9,16]
for i in a:
    if type(i)==int:
        if i%2==0:
            sum=sum+i
        else:
            sum=sum-i
print(sum)
