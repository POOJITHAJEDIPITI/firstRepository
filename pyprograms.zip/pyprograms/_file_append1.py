file=open('sample.txt','a')
data='\n11.Narasimha'
file.write(data)
file.close()


file=open('sample.txt','r')
data=file.read()
print(data)