a=[1,2,3]
if 4 in a:
    print('yes')

