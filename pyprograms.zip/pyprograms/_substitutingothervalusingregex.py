import re
out=re.sub('[aeiou]','*','vikitha')
print(out)