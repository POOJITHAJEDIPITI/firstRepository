a=eval(input('enter a character'))
if a in [0,1,2,3,4,5,6,7,8,9]:
 print('true')
else:
 print('false')