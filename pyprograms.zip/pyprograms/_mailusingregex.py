import re
out=re.findall('[a-zA-Z0-9]+\.?[a-zA-Z0-9]*\@gmail\.com','abcd123.#gmail.com#abcd@gmail.com#asdf123#asdf123@gmail.com')
print(out)