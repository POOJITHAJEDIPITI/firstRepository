class num:
    def __init__(self,a):
        self.a=a
    def __str__(self):
          return str(self.a)
    def square(self):
           return self.a**2
    def cube(self):
          return self.a**3
    def double(self):
          return self.a*2
    def  iseven(self):
          if self.a%2==0:
                return 'even'
          else:
                return 'odd'
    def increment(self,n=1):
          self.a=self.a+n
          return self.a

    def prime(self):
          count=0
   # if num>1 and isinstance(num,int):
          for i in range(1,self.a+1):
               if self.a%i==0:
                    count+=1   
          if count==2:
                 return 'prime'
          else:
                 return 'not prime'
    def factorial(self):
          fact=1
          for i in range(1,self.a+1):
              fact*=i
          return fact
    def positive(self):
          if self.a>0:
                return 'positive'
          else:
                return 'negative'

a=num(2)
print(a.square())
#a=num(4)
print(a.prime())
print(a.positive())
print(a.cube())
print(a.double())
print(a.iseven())
print(a.factorial())
print(a.increment())
print(a.increment())
print(a)