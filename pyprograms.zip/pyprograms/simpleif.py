a='vikitha'
if len(a)>5:
    print('yes')
