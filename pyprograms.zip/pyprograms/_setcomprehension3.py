def fun():
    a={'a':'abc', 1 : 1234,'b':'bcde', 2 : 2345}#output {'abc':'a','bcde':'b'}
    out={ a[i]:i for i in a if type(i)==str}
    return out
print(fun())