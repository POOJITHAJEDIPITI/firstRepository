a=[2,57,8,6,4,3,23,2,1,21,35,8,9]
def multiple3(num):
    if num%3==0:
        return True
    else:
        return False
out=list(filter(multiple3,a))#list(filter(lambda num:num%3==0,b))
print(out)
    
