#file=open("D:\\pyprograms\\sample.txt",'r')#using one more slash to remove the spl menaing of the slash
file=open(r"C:\Users\administrator.MCA\Desktop\new.txt",'r')#raw string
data=file.read()
print(data)
file.close()