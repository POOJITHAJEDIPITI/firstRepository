#file=open('sample.txt','w')
#data='''
#1.nandan
#2.nanditha
#3.namratha
#4.naveen
#5.nagaveni
#6.naga
#7.nagendra
#8.nagalakshmi
#9.navitha
#10.narendra'''
#file.write(data)
#file.close()

file=open('sample.txt','r')
data=file.read()
print(data)