name=input('enter name  ')
if len(name)<4:
    raise Exception
else:
    print('hi',name)