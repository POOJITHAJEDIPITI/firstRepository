class mtca:
    college='mti'
    principal='Mr.prabhakar'
    location='palamaner'
    def __init__(self,sname,mobile,email):
        self.name=sname
        self.mnum=mobile
        self.mail=email
    def mob_update(self,new):
        self.mnum=new
        print('mobile number updated')

student1=mtca('vikitha',9999999,'viki@gmail.com')
student1.mob_update(987654)
print(student1.name)
print(student1.mail)
print(student1.mnum)
print(student1.college)
print(student1.principal)
print(student1.location)
print(student1.__dict__)
