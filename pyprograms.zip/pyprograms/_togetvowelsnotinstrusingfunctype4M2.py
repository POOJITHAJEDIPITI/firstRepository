def vowel1(str):
    vowel='aeiouAEIOU'
    out=''
    for k in str:
        if k in vowel:
            out+=k
    res=''
    for j in vowel:
        if j not in out:
            res+=j
    return res
print(vowel1('vikitha'))
