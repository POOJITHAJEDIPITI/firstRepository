a=int(input('enter a number'))
b=int(input('enter a number'))
operation=input('enter operation')
match operation:
    case '+':
        print(a+b)
    case '-':
        print(a-b)
    case '*':
        print(a*b)
    case '%':
        print(a%b)
    case '/':
        print(a/b)
    case '//':
        print(a//b)
    case _:
        print('INVALID')