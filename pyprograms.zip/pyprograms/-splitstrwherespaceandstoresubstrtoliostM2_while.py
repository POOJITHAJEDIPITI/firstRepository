str=input('enter a string')
out=[]
i=0
temp=''
while i<len(str):
    if str[i]!=' ':
        temp+=str[i]
    else:
        out+=[temp]
        temp=''
    i+=1
#else:
if temp:
        out+=[temp]
print(out)