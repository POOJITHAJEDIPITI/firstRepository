def product():
    a=int(input('enter a value'))
    b=int(input('enter b value'))
    c=a*b
    #return 0 (output 0 only)
      #print('product of a and b is', c)
    return c
    print('hi')
d=product()
print(d)