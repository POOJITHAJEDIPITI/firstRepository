def lowtoup():
    a=input('enter a string')
    b=''
    for k in a:
        if 'a'<=k<='z':
           b+=chr(ord(k)-32)
        else:  
           b+=chr(ord(k)+32)
    return b
x=lowtoup()
print(x)

