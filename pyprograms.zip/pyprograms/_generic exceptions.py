a=10

try:
    a/0#ZeroDivisionError
    print(b)#NameError
    a+'12'#TypeError
except Exception:
    print('handled')
