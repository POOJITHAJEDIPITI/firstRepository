a=10
def fun():
    c=20
    def fun1():
        nonlocal c
        c=40
        print(c)
    print(c)
    fun1()
    print(c)
    #fun1()
fun()