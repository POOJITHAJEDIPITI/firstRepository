import re
out=re.findall('AP[0-9]{2}[^a-zA-Z0-9][A-Z][^a-zA-Z0-9][0-9]{4}','AP01 A 1234')
out=re.findall('AP ?[0-3][1-9] ?[a-zA-Z] ?[0-9]{4}','sdfgAP01fghA1234')
print(out)