a=10
b=20
def fun():
    c=20
    print(a)
#print(c)
fun()
print(c)