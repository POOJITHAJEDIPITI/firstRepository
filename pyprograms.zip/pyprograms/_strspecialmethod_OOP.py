class demo:#without str method if we print(obj) we will get address of objec but with str spl method we will get the value for object
    
    def __init__(self,a):
        self.a=a
    #def __repr__(self):
       # return str(self.a)
    def __str__(self):
        return str(self.a)
    
obj=demo(4)
print(obj)