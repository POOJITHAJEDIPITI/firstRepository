class bank:
    bname='icici'
    bmanager='vikitha'
    bbranch='chittoor'
    bifsc='oib123'
    def __init__(self,name,mobile,address,aadharno,balance):
        